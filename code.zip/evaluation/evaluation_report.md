# Operational Analysis

This report covers the actual shipped dataset as provided with this
challenge: `dataset/sample_claims.csv` (20 labeled rows, 29 images) and
`dataset/claims.csv` (44 unlabeled rows, 82 images) — 64 claims and 111
images total. All numbers below are estimates computed from this exact
row/image count using documented Anthropic pricing and the published
vision token formula, not measured from a live run (this assistant's
sandboxed dev environment had no access to the Anthropic API or to
PyPI — see the chat transcript for how the offline parts were validated
instead). Re-running `evaluation/evaluate.py` and `main.py` with a real
`ANTHROPIC_API_KEY` will print the *actual* `usage_summary()` from
`pipeline.py`, which logs real `input_tokens`/`output_tokens` per call —
treat the numbers below as the pre-registered estimate to compare that
against.

## Architecture recap (relevant to the cost model)

One Claude Sonnet 4.6 call per **claim** (not per image): every image
belonging to a claim is sent in the same multimodal request, alongside the
transcript, the evidence-requirement checklist, and a forced
`record_claim_review` tool call for structured output. See
`code/evidence_review/vision_agent.py` for the full prompt and schema.

## Call counts

| Dataset | Rows | Images | Model calls (1 per row) |
|---|---|---|---|
| `sample_claims.csv` | 20 | 29 | 20 |
| `claims.csv` (test) | 44 | 82 | 44 |
| **Total** | **64** | **111** | **64** |

Calls equal row count exactly, by construction — never per-image, never
per-field. A disk cache (`pipeline.DiskCache`, keyed on prompt-version +
model + transcript + claim_object + each image's path/size/mtime) means
re-running the same row after a non-prompt-affecting code change (e.g.
editing `decision.py`) costs **zero** additional live calls; the call count
above is the worst case ("every row cold").

## Token usage estimate

Per-image cost uses Anthropic's documented vision formula,
`tokens ≈ (width × height) / 750`, capped at Sonnet's standard-resolution
ceiling of ~1568 tokens/image once resized to the recommended 1568px long
edge. We use that ceiling as a conservative per-image estimate (real claim
photos are likely smaller, e.g. compressed phone camera uploads, so this
overestimates rather than underestimates).

Per-call text overhead breakdown:
- System prompt (`vision_agent.SYSTEM_PROMPT`): ~700 tokens
- `record_claim_review` tool schema (sent as part of input on every call): ~500 tokens
- Transcript + evidence checklist text + object-part vocabulary + framing: ~400 tokens
- Output (structured tool-call JSON: extracted_claim, per_image_notes, justification, etc.): ~350 tokens

| Dataset | Calls | Est. input tokens | Est. output tokens |
|---|---|---|---|
| `sample_claims.csv` | 20 | ~77,500 | ~7,000 |
| `claims.csv` (test) | 44 | ~199,000 | ~15,400 |
| **Total (one full pass each)** | **64** | **~276,500** | **~22,400** |

## Cost estimate

Pricing assumption: **Claude Sonnet 4.6**, standard synchronous API,
$3/MTok input, $15/MTok output (Anthropic's published rate as of this
writing; output is 5x input as with all current-generation models).

| Scenario | Estimated cost |
|---|---|
| `sample_claims.csv` only (sync, standard pricing) | **~$0.34** |
| `claims.csv` test set only (sync, standard pricing) | **~$0.83** |
| Combined, one full pass of each | **~$1.17** |
| `claims.csv` test set via Message Batches API (50% off) | **~$0.41** |

At this volume (64 rows total) the absolute dollar cost is trivial either
way — the batching/caching strategy below is documented primarily because
the assignment asks us to show we *considered* cost/latency/rate-limit
tradeoffs, and because the same architecture should degrade gracefully if
claim volume were 100x larger (6,400 rows, ~$83-117 per full pass at sync
pricing, ~$41-58 via Batch API).

**Prompt caching opportunity:** the system prompt + tool schema (~1,200
tokens) are identical on every call. With Anthropic's prompt caching
(`cache_control` breakpoints, 90% discount on cached reads after the first
call), running the full 44-row test set saves roughly **$0.14** versus
paying full input price for that fixed block on every call — a ~17% cut on
the input-token portion of the bill at this volume, growing in relative
importance as the system prompt grows or volume scales up. This is not
wired into the current `vision_agent.py` (the savings are sub-cent at this
scale and adding cache breakpoints adds a small amount of code complexity
that isn't justified yet), but the integration point is a one-line addition
(`"cache_control": {"type": "ephemeral"}` on the system block) and is noted
here as the first lever to pull if volume grows.

## Latency / runtime estimate

Assuming ~10-15s per call (typical round-trip for a multimodal tool-use
request with 1-3 images and a ~350-token structured response):

| Concurrency | Estimated wall-clock time, 44-row test set |
|---|---|
| Sequential (1 worker) | ~7-9 minutes |
| 4 workers (this pipeline's default, `--max-workers 4`) | ~2-3 minutes |

`pipeline.py` uses a `ThreadPoolExecutor` (not multiprocessing) because the
work is I/O-bound on the network round-trip, not CPU-bound — threads avoid
the overhead of separate processes for what is fundamentally "wait for an
HTTP response."

## TPM/RPM and throttling strategy

- At 4 concurrent workers issuing one call roughly every ~12s each, sustained
  throughput is on the order of **~20 requests/minute**, comfortably under
  typical Anthropic per-minute request limits for an individual/low API tier
  (which are commonly in the tens-to-low-hundreds of RPM range; exact limits
  depend on the account's usage tier and should be checked in the Anthropic
  Console before a large production run).
- Per-call input size (~3,100-4,500 tokens for a 1-3 image claim) is far
  below typical TPM ceilings, so RPM — not TPM — is the binding constraint
  at this volume.
- `vision_agent.VisionAgent.review_claim` retries on `RateLimitError`
  (HTTP 429) and transient 5xx `APIStatusError`s with exponential backoff
  (`BASE_BACKOFF_SECONDS=2`, doubling, up to `MAX_RETRIES=4`), so a transient
  rate-limit hit slows a single row down rather than failing the batch.
- `--max-workers` is a CLI flag specifically so it can be turned down for a
  lower API tier or up for a higher one, without touching code.
- **Batch API path** (`code/evidence_review/batch_runner.py`): built and
  documented as the production-scale alternative once claim volume is large
  enough that the 50%-discount and slower (up to ~24h) turnaround become the
  right trade against the synchronous path's faster feedback loop. It
  reuses the exact same system prompt, tool schema, and image-encoding logic
  as the synchronous path (imported directly from `vision_agent.py`), so the
  two paths cannot silently diverge in what verdict they'd produce for the
  same input. Not wired into `main.py`'s default path for this submission
  because 44 rows comfortably finishes synchronously in a couple of minutes
  with the cache+thread-pool path, and the dev-loop benefit of fast
  synchronous feedback while iterating on `sample_claims.csv` outweighs the
  discount at this volume.

## Avoiding unnecessary repeated calls

- **Disk cache** (`pipeline.DiskCache`): content-addressed by a hash of
  prompt version + model name + transcript + claim_object + each image
  path's size/mtime. Re-running `main.py` or `evaluate.py` after a change
  to `decision.py`, `schema.py`, `user_history.py`, or
  `evidence_requirements.py` (none of which affect the prompt sent to the
  model) costs zero additional live calls for unchanged rows — only edits
  to `vision_agent.py`'s prompt/schema (which bump `PROMPT_VERSION`) force
  a re-call. This was the single highest-leverage cost optimization for the
  actual development workflow this challenge asks for: iterating against
  `sample_claims.csv` repeatedly while tuning prompts/decision logic.
- **One call per claim, not per image**: already covered above, but it's
  also a cost lever — N images in one call costs roughly the same total
  image tokens as N separate calls, but avoids paying the ~1,200-token
  system-prompt-and-tool-schema overhead N times instead of once.
- **Per-row error isolation with fallback rows** (`decision.build_fallback_row`)
  means a transient failure on one row, even after retries are exhausted,
  does not force a full re-run of the batch — only that one row needs to be
  retried, and it's already marked `manual_review_required` in the
  meantime so the output CSV is never silently wrong.
