#!/usr/bin/env python3
"""
evaluate.py
============
Evaluation harness required by problem_statement.md: "Use
dataset/sample_claims.csv to evaluate your system before producing final
predictions for dataset/claims.csv."

sample_claims.csv ships BOTH inputs and expected outputs in the same row
(14 input+output columns together, no separate "expected_output.csv").
This script:

  1. Strips the input columns out, runs them through the same
     ClaimReviewPipeline used for the real test set (so we're evaluating
     the actual production code path, not a separate "eval-only" copy of
     the logic),
  2. Compares predictions to the expected columns already present in
     sample_claims.csv, field by field,
  3. Prints a per-field accuracy table and writes a row-by-row diff CSV so
     disagreements are easy to inspect by hand,
  4. Writes evaluation/sample_predictions.csv (predictions only, same
     schema as output.csv) for archival / re-inspection.

Usage:
    python evaluation/evaluate.py --sample dataset/sample_claims.csv

Exits non-zero if the harness itself errors (e.g. missing API key), but
NEVER hardcodes or special-cases any sample_claims.csv row -- the pipeline
under test has no knowledge of which rows are "the sample set" versus
"the real test set"; this script only reads expected_* values for scoring
after predictions are produced independently.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "code"))

from evidence_review import schema  # noqa: E402
from evidence_review.pipeline import ClaimInputRow, ClaimReviewPipeline, write_output_csv  # noqa: E402

INPUT_COLUMNS = ["user_id", "image_paths", "user_claim", "claim_object"]
SCORABLE_COLUMNS = [c for c in schema.OUTPUT_COLUMNS if c not in INPUT_COLUMNS]

# Columns where we score with set-equality over the semicolon-separated list
# rather than exact string equality, since column order within the field is
# not semantically meaningful (e.g. "img_1;img_2" vs "img_2;img_1").
SET_VALUED_COLUMNS = {"risk_flags", "supporting_image_ids"}

# Free-text columns are reported as present/non-empty rather than scored for
# exact match, since two correct justifications can be worded differently.
FREE_TEXT_COLUMNS = {"evidence_standard_met_reason", "claim_status_justification"}


def read_sample_with_expected(path: str):
    input_rows = []
    expected_rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            input_rows.append(
                ClaimInputRow(
                    user_id=(r.get("user_id") or "").strip(),
                    image_paths_field=(r.get("image_paths") or "").strip(),
                    user_claim=r.get("user_claim") or "",
                    claim_object=(r.get("claim_object") or "").strip().lower(),
                )
            )
            expected_rows.append({c: (r.get(c) or "").strip() for c in schema.OUTPUT_COLUMNS})
    return input_rows, expected_rows


def _set_eq(a: str, b: str) -> bool:
    sa = {x.strip().lower() for x in a.split(";") if x.strip()}
    sb = {x.strip().lower() for x in b.split(";") if x.strip()}
    return sa == sb


def score(predicted_rows: list[dict], expected_rows: list[dict]) -> dict:
    per_field_correct = {c: 0 for c in SCORABLE_COLUMNS}
    per_field_total = {c: 0 for c in SCORABLE_COLUMNS}
    row_fully_correct = 0
    diffs = []

    key_fields = [c for c in SCORABLE_COLUMNS if c not in FREE_TEXT_COLUMNS]

    for idx, (pred, exp) in enumerate(zip(predicted_rows, expected_rows)):
        row_ok = True
        row_diff = {"row_index": idx, "user_id": pred.get("user_id", "")}
        for col in SCORABLE_COLUMNS:
            if col in FREE_TEXT_COLUMNS:
                # presence check only; not scored for exact match
                continue
            per_field_total[col] += 1
            p_val = (pred.get(col) or "").strip().lower()
            e_val = (exp.get(col) or "").strip().lower()
            if col in SET_VALUED_COLUMNS:
                match = _set_eq(p_val, e_val)
            else:
                match = p_val == e_val
            if match:
                per_field_correct[col] += 1
            else:
                row_ok = False
                row_diff[col] = {"predicted": pred.get(col), "expected": exp.get(col)}
        if not row_ok:
            diffs.append(row_diff)
        else:
            row_fully_correct += 1

    accuracy_by_field = {
        c: (per_field_correct[c] / per_field_total[c] if per_field_total[c] else None)
        for c in key_fields
    }
    return {
        "n_rows": len(predicted_rows),
        "exact_row_match_rate": row_fully_correct / len(predicted_rows) if predicted_rows else 0.0,
        "accuracy_by_field": accuracy_by_field,
        "diffs": diffs,
    }


def print_report(result: dict) -> None:
    print(f"\n{'='*60}")
    print(f"Evaluation against sample_claims.csv  ({result['n_rows']} rows)")
    print(f"{'='*60}")
    print(f"Exact full-row match rate: {result['exact_row_match_rate']*100:.1f}%\n")
    print(f"{'Field':<32}{'Accuracy':>10}")
    print("-" * 42)
    for field, acc in result["accuracy_by_field"].items():
        acc_str = f"{acc*100:.1f}%" if acc is not None else "n/a"
        print(f"{field:<32}{acc_str:>10}")
    print()
    if result["diffs"]:
        print(f"{len(result['diffs'])} row(s) had at least one mismatched field. "
              f"See sample_eval_diffs.csv for details.")
    else:
        print("All rows matched on every scored field.")


def write_diffs_csv(diffs: list[dict], path: str) -> None:
    if not diffs:
        return
    all_cols = set()
    for d in diffs:
        all_cols.update(d.keys())
    all_cols = ["row_index", "user_id"] + sorted(c for c in all_cols if c not in ("row_index", "user_id"))
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_cols)
        writer.writeheader()
        for d in diffs:
            row = {}
            for c in all_cols:
                v = d.get(c, "")
                row[c] = str(v) if not isinstance(v, str) else v
            writer.writerow(row)


def main() -> int:
    parser = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    parser.add_argument("--sample", default=os.path.join(here, "..", "dataset", "sample_claims.csv"))
    parser.add_argument("--dataset-root", default=os.path.join(here, "..", "dataset"))
    parser.add_argument("--model", default=os.environ.get("EVIDENCE_REVIEW_MODEL", "claude-sonnet-4-6"))
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--cache-dir", default=os.path.join(here, "..", "code", ".cache"))
    parser.add_argument("--predictions-out", default=os.path.join(here, "sample_predictions.csv"))
    parser.add_argument("--diffs-out", default=os.path.join(here, "sample_eval_diffs.csv"))
    args = parser.parse_args()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ERROR: ANTHROPIC_API_KEY is not set.", file=sys.stderr)
        return 1

    input_rows, expected_rows = read_sample_with_expected(args.sample)
    print(f"[INFO] loaded {len(input_rows)} labeled sample rows", file=sys.stderr)

    pipeline = ClaimReviewPipeline(
        dataset_root=args.dataset_root,
        evidence_requirements_path=os.path.join(args.dataset_root, "evidence_requirements.csv"),
        user_history_path=os.path.join(args.dataset_root, "user_history.csv"),
        model=args.model,
        cache_dir=args.cache_dir or None,
        max_workers=args.max_workers,
    )
    predicted_rows = pipeline.run(input_rows)
    write_output_csv(predicted_rows, args.predictions_out)

    result = score(predicted_rows, expected_rows)
    print_report(result)
    write_diffs_csv(result["diffs"], args.diffs_out)

    usage = pipeline.usage_summary()
    print(f"\n[INFO] usage summary: {usage}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
