"""
batch_runner.py
================
Optional alternative execution path using Anthropic's Message Batches API
instead of synchronous ThreadPoolExecutor calls (pipeline.py's default path).

Why this exists as a SEPARATE, optional module rather than the default:
  - The Batch API gives a 50% discount on both input and output tokens,
    which matters once claim volume is large (hundreds/thousands of rows).
  - But batches can take up to 24h to complete and have less predictable
    turnaround than synchronous calls, which is a poor fit for the
    iterate-on-sample_claims.csv development loop (you want fast feedback
    while tuning the prompt). So: synchronous + disk cache for dev and for
    the relatively small test set actually shipped with this challenge
    (45 rows), batch API documented here as the production-scale answer.
  - This module builds the exact same per-claim request body the synchronous
    VisionAgent builds (same system prompt, same tool schema, same image
    encoding) by reusing vision_agent.build_user_content /
    RECORD_CLAIM_REVIEW_TOOL / SYSTEM_PROMPT, so the two paths cannot drift
    into giving different verdicts for the same input.

Usage (illustrative -- not wired into main.py by default since the shipped
test set is small enough that synchronous+cache is faster end-to-end):

    from evidence_review.batch_runner import submit_batch, collect_batch_results

    batch_id = submit_batch(client, claim_rows, dataset_root, evidence_store, history_store)
    # ... poll client.messages.batches.retrieve(batch_id) until status == "ended" ...
    verdicts_by_custom_id = collect_batch_results(client, batch_id)
"""

from __future__ import annotations

import json
from typing import Any

import anthropic

from . import schema
from .conversation import detect_injection_attempts, format_transcript_for_prompt
from .evidence_requirements import EvidenceRequirementStore
from .user_history import UserHistoryStore
from .vision_agent import RECORD_CLAIM_REVIEW_TOOL, SYSTEM_PROMPT, build_user_content


def build_batch_requests(
    claim_rows: list,
    dataset_root: str,
    evidence_store: EvidenceRequirementStore,
    history_store: UserHistoryStore,
) -> list[dict]:
    """
    Build one Message Batches API request per claim row. `custom_id` is set
    to the row's user_id + a stable index so results can be matched back to
    input rows after the batch completes (the Batches API returns results
    in a JSONL keyed by custom_id, not necessarily in submission order).
    """
    from .pipeline import resolve_image_paths

    requests = []
    for idx, row in enumerate(claim_rows):
        image_abs_paths = [
            p for p in resolve_image_paths(dataset_root, row.image_paths_field)
        ]
        transcript = format_transcript_for_prompt(row.user_claim)
        history_risk = history_store.assess(row.user_id)
        evidence_text = evidence_store.full_reference_block(row.claim_object)
        object_part_vocab = sorted(
            schema.OBJECT_PARTS_BY_OBJECT.get(row.claim_object, {"unknown"})
        )

        content = build_user_content(
            transcript=transcript,
            claim_object=row.claim_object,
            image_abs_paths=image_abs_paths,
            evidence_checklist_text=evidence_text,
            object_part_vocab=object_part_vocab,
            history_context_note=history_risk.note,
        )

        requests.append({
            "custom_id": f"{idx:05d}_{row.user_id}",
            "params": {
                "model": "claude-sonnet-4-6",
                "max_tokens": 1500,
                "system": SYSTEM_PROMPT,
                "tools": [RECORD_CLAIM_REVIEW_TOOL],
                "tool_choice": {"type": "tool", "name": "record_claim_review"},
                "messages": [{"role": "user", "content": content}],
            },
        })
    return requests


def submit_batch(client: "anthropic.Anthropic", requests: list[dict]) -> str:
    batch = client.messages.batches.create(requests=requests)
    return batch.id


def collect_batch_results(client: "anthropic.Anthropic", batch_id: str) -> dict[str, Any]:
    """Returns {custom_id: parsed_tool_input_dict_or_error}."""
    results: dict[str, Any] = {}
    for entry in client.messages.batches.results(batch_id):
        if entry.result.type == "succeeded":
            message = entry.result.message
            tool_block = next(
                (b for b in message.content if getattr(b, "type", None) == "tool_use"),
                None,
            )
            results[entry.custom_id] = tool_block.input if tool_block else {"error": "no tool_use block"}
        else:
            results[entry.custom_id] = {"error": entry.result.type}
    return results
