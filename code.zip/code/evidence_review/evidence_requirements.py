"""
evidence_requirements.py
=========================
Loads dataset/evidence_requirements.csv:

    requirement_id, claim_object, applies_to, minimum_image_evidence

`claim_object` is one of car/laptop/package/all.
`applies_to` is an "issue family" string, e.g. "dent or scratch".

This module's job is purely retrieval: given a claim_object and a rough
issue-family guess (e.g. from the conversation, before we've even looked at
images), find the matching requirement row(s) and hand their
`minimum_image_evidence` text to the VLM prompt so the model knows exactly
what standard of evidence it's checking against -- instead of inventing its
own ad hoc bar for "enough evidence" on every single row.

Matching strategy:
  - exact claim_object match, OR claim_object == 'all'
  - `applies_to` is matched loosely: split on '/', ',', ' or ' and check
    for any overlap with issue-family keywords we infer from the claim text
  - if nothing matches, fall back to any 'all'-scoped rule for that object,
    and finally to a generic default string so the prompt is never empty.
"""

from __future__ import annotations

import csv
import os
import re
from dataclasses import dataclass


@dataclass
class EvidenceRequirement:
    requirement_id: str
    claim_object: str
    applies_to: str
    minimum_image_evidence: str


_SPLIT_RE = re.compile(r",|/|\bor\b", re.IGNORECASE)


def _keywords(text: str) -> set[str]:
    return {w.strip().lower() for w in _SPLIT_RE.split(text) if w.strip()}


class EvidenceRequirementStore:
    DEFAULT_REQUIREMENT = (
        "At least one clear, unobstructed, adequately lit image of the "
        "specific claimed part, close enough to verify the presence or "
        "absence of the described issue."
    )

    def __init__(self, csv_path: str):
        self._rows: list[EvidenceRequirement] = []
        if csv_path and os.path.exists(csv_path):
            self._load(csv_path)

    def _load(self, csv_path: str) -> None:
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                self._rows.append(
                    EvidenceRequirement(
                        requirement_id=(row.get("requirement_id") or "").strip(),
                        claim_object=(row.get("claim_object") or "").strip().lower(),
                        applies_to=(row.get("applies_to") or "").strip(),
                        minimum_image_evidence=(row.get("minimum_image_evidence") or "").strip(),
                    )
                )

    def all_for_object(self, claim_object: str) -> list[EvidenceRequirement]:
        """All rules that could apply to this object (object-specific + 'all')."""
        claim_object = (claim_object or "").strip().lower()
        return [
            r for r in self._rows
            if r.claim_object == claim_object or r.claim_object == "all"
        ]

    def best_match_text(self, claim_object: str, issue_hint: str) -> str:
        """
        Return the minimum_image_evidence text most relevant to this claim.
        `issue_hint` is a free-text guess at the issue family pulled from the
        raw conversation (e.g. "dent", "windshield shatter", "missing item").
        This is intentionally a soft, best-effort match: if the evidence
        requirements file doesn't have a perfect row, we still want to give
        the model *some* concrete bar rather than nothing.
        """
        candidates = self.all_for_object(claim_object)
        if not candidates:
            return self.DEFAULT_REQUIREMENT

        hint_words = _keywords(issue_hint or "")
        best = None
        best_score = 0
        for r in candidates:
            applies_words = _keywords(r.applies_to)
            score = len(hint_words & applies_words)
            if score > best_score:
                best_score = score
                best = r

        if best is not None and best_score > 0:
            return best.minimum_image_evidence

        # fall back to an object-scoped 'all' rule if present, else the
        # first object-specific rule, else the hardcoded default.
        all_scoped = [r for r in candidates if r.claim_object == "all"]
        if all_scoped:
            return all_scoped[0].minimum_image_evidence
        if candidates:
            return candidates[0].minimum_image_evidence
        return self.DEFAULT_REQUIREMENT

    def full_reference_block(self, claim_object: str) -> str:
        """
        Render every requirement applicable to this object as a readable
        block, so the model can see the *entire* checklist for this object
        type rather than a single matched row -- useful because the
        conversation's issue family is sometimes ambiguous or multi-part
        (e.g. case_001: bumper + headlight in one claim).
        """
        candidates = self.all_for_object(claim_object)
        if not candidates:
            return f"(no specific evidence rules on file; default standard: {self.DEFAULT_REQUIREMENT})"
        lines = []
        for r in candidates:
            lines.append(f"- [{r.requirement_id}] applies_to='{r.applies_to}': {r.minimum_image_evidence}")
        return "\n".join(lines)
