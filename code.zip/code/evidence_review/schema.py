"""
schema.py
=========
Single source of truth for the output schema and the controlled vocabularies
("allowed values") defined in problem_statement.md.

Keeping these as plain Python constants (rather than re-deriving them ad hoc
in prompts or post-processing code) means:
  1. The CSV writer can validate every row before it ever hits disk.
  2. The LLM-facing prompt and the validator are built from the same list,
     so they cannot silently drift apart.
  3. Unknown/invalid values get *clamped* to the closest allowed value
     instead of crashing the batch run or producing an uncheckable CSV.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Output column order (must match problem_statement.md exactly)
# ---------------------------------------------------------------------------
OUTPUT_COLUMNS = [
    "user_id",
    "image_paths",
    "user_claim",
    "claim_object",
    "evidence_standard_met",
    "evidence_standard_met_reason",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "claim_status_justification",
    "supporting_image_ids",
    "valid_image",
    "severity",
]

# ---------------------------------------------------------------------------
# Allowed values
# ---------------------------------------------------------------------------
CLAIM_OBJECTS = {"car", "laptop", "package"}

CLAIM_STATUSES = {"supported", "contradicted", "not_enough_information"}

ISSUE_TYPES = {
    "dent",
    "scratch",
    "crack",
    "glass_shatter",
    "broken_part",
    "missing_part",
    "torn_packaging",
    "crushed_packaging",
    "water_damage",
    "stain",
    "none",
    "unknown",
}

OBJECT_PARTS_BY_OBJECT = {
    "car": {
        "front_bumper", "rear_bumper", "door", "hood", "windshield",
        "side_mirror", "headlight", "taillight", "fender", "quarter_panel",
        "body", "unknown",
    },
    "laptop": {
        "screen", "keyboard", "trackpad", "hinge", "lid", "corner",
        "port", "base", "body", "unknown",
    },
    "package": {
        "box", "package_corner", "package_side", "seal", "label",
        "contents", "item", "unknown",
    },
}

RISK_FLAGS = {
    "none",
    "blurry_image",
    "cropped_or_obstructed",
    "low_light_or_glare",
    "wrong_angle",
    "wrong_object",
    "wrong_object_part",
    "damage_not_visible",
    "claim_mismatch",
    "possible_manipulation",
    "non_original_image",
    "text_instruction_present",
    "user_history_risk",
    "manual_review_required",
}

SEVERITIES = {"none", "low", "medium", "high", "unknown"}

BOOL_STRINGS = {"true", "false"}


def closest_object_part(claim_object: str, candidate: str) -> str:
    """Return `candidate` if it is valid for claim_object, else 'unknown'."""
    allowed = OBJECT_PARTS_BY_OBJECT.get(claim_object, set())
    candidate = (candidate or "").strip().lower()
    return candidate if candidate in allowed else "unknown"


def clamp_issue_type(candidate: str) -> str:
    candidate = (candidate or "").strip().lower()
    return candidate if candidate in ISSUE_TYPES else "unknown"


def clamp_severity(candidate: str) -> str:
    candidate = (candidate or "").strip().lower()
    return candidate if candidate in SEVERITIES else "unknown"


def clamp_claim_status(candidate: str) -> str:
    candidate = (candidate or "").strip().lower()
    return candidate if candidate in CLAIM_STATUSES else "not_enough_information"


def clamp_bool_str(candidate, default: str = "false") -> str:
    if isinstance(candidate, bool):
        return "true" if candidate else "false"
    candidate = str(candidate).strip().lower()
    return candidate if candidate in BOOL_STRINGS else default


def clean_risk_flags(flags) -> str:
    """
    Normalize a list/set/semicolon-string of risk flags into the
    semicolon-joined, deduplicated, schema-valid string the CSV expects.
    Falls back to 'none' if nothing valid survives filtering.
    """
    if flags is None:
        return "none"
    if isinstance(flags, str):
        parts = [p.strip().lower() for p in flags.split(";")]
    else:
        parts = [str(p).strip().lower() for p in flags]

    valid = [p for p in parts if p in RISK_FLAGS and p != "none"]
    # de-duplicate while preserving first-seen order (stable, readable output)
    seen = []
    for v in valid:
        if v not in seen:
            seen.append(v)
    return ";".join(seen) if seen else "none"
