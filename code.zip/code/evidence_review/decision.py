"""
decision.py
============
Fuses the model's VisionVerdict with deterministic context
(user-history risk, image-path sanity checks) into one schema-valid output
row. This is intentionally a *thin*, fully deterministic layer:

  - it never re-judges the images,
  - it never overturns claim_status, issue_type, object_part, or
    evidence_standard_met based on history alone (per spec: history adds
    risk context, it does not override visual evidence),
  - its only jobs are: (a) merge risk-flag lists from different sources
    without duplication, (b) decide when `manual_review_required` should be
    added on top of the model's own flags, (c) clamp every field to the
    allowed vocabulary so a malformed/unexpected model output can never
    produce an invalid CSV row, and (d) decide `valid_image` from a
    combination of file-existence checks and the model's own
    valid_image_set signal.

`manual_review_required` policy (deterministic, explainable):
    added when ANY of the following hold:
      - the model's own model_confidence is "low"
      - claim_status == "contradicted" (mismatches are exactly the cases a
        human probably wants to sanity check before denying someone)
      - user-history risk flags fired AND claim_status != "not_enough_information"
        (don't pile on a case that's already inconclusive)
      - possible_manipulation or non_original_image was flagged
      - text_instruction_present was flagged (an injection attempt warrants
        human eyes regardless of which claim_status the model otherwise
        reached, since the whole point is that the model's output can't be
        fully trusted to self-report when it's the target of manipulation)
This mirrors the pattern visible in sample_claims.csv itself (rows with
claim_mismatch or possible_manipulation consistently also carry
manual_review_required), so it's not an arbitrary policy -- it's made
explicit and explained rather than left for the LLM to decide ad hoc.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

from . import schema
from .user_history import HistoryRisk
from .vision_agent import VisionVerdict


@dataclass
class FinalRow:
    user_id: str
    image_paths: str
    user_claim: str
    claim_object: str
    evidence_standard_met: str
    evidence_standard_met_reason: str
    risk_flags: str
    issue_type: str
    object_part: str
    claim_status: str
    claim_status_justification: str
    supporting_image_ids: str
    valid_image: str
    severity: str

    def as_row(self) -> dict:
        return {c: getattr(self, c) for c in schema.OUTPUT_COLUMNS}


def _check_images_exist(image_abs_paths: list[str]) -> tuple[list[str], list[str]]:
    """Returns (existing_paths, missing_image_ids)."""
    existing = []
    missing_ids = []
    for p in image_abs_paths:
        image_id = os.path.splitext(os.path.basename(p))[0]
        if os.path.isfile(p):
            existing.append(p)
        else:
            missing_ids.append(image_id)
    return existing, missing_ids


def build_final_row(
    *,
    user_id: str,
    image_paths_field: str,
    user_claim: str,
    claim_object: str,
    verdict: VisionVerdict,
    history_risk: HistoryRisk,
    injection_detected: bool,
    missing_image_ids: list[str],
    all_image_ids: list[str],
) -> FinalRow:
    claim_object = (claim_object or "").strip().lower()

    # --- risk flags: union of model-reported + deterministic signals -----
    risk_flags: list[str] = list(verdict.risk_flags)

    if injection_detected and "text_instruction_present" not in risk_flags:
        risk_flags.append("text_instruction_present")

    if missing_image_ids:
        if "cropped_or_obstructed" not in risk_flags:
            # a referenced image that doesn't exist/load is treated like an
            # unusable image for review purposes
            risk_flags.append("cropped_or_obstructed")

    risk_flags.extend(history_risk.risk_flags)  # adds 'user_history_risk' if applicable

    # --- clamp core fields to the allowed vocabulary -----------------------
    claim_status = schema.clamp_claim_status(verdict.claim_status)
    issue_type = schema.clamp_issue_type(verdict.issue_type)
    object_part = schema.closest_object_part(claim_object, verdict.object_part)
    severity = schema.clamp_severity(verdict.severity)

    # internal consistency guard: not_enough_information should not claim a
    # known severity (severity should read 'unknown' in that case, matching
    # the pattern in sample_claims.csv for not_enough_information rows).
    if claim_status == "not_enough_information" and severity not in ("unknown",):
        severity = "unknown"
    if claim_status == "not_enough_information" and issue_type not in ("unknown",):
        issue_type = "unknown"

    # internal consistency guard: claim_status and evidence_standard_met are
    # logically linked, not just correlated -- you cannot have reached a
    # supported/contradicted verdict from evidence you also said was
    # insufficient, and conversely you cannot call evidence "sufficient"
    # while still saying you don't have enough information. In every labeled
    # row of sample_claims.csv this holds as a strict equivalence:
    # evidence_standard_met == false  <=>  claim_status == not_enough_information.
    # We enforce the direction that's unambiguous to resolve automatically
    # (let claim_status drive evidence_standard_met, since claim_status is the
    # primary decision the model reasons hardest about) rather than silently
    # trusting two possibly-contradictory model outputs.
    if claim_status == "not_enough_information":
        evidence_standard_met_bool = False
    else:
        evidence_standard_met_bool = verdict.evidence_standard_met

    valid_image_set = verdict.valid_image_set and not (
        missing_image_ids and len(missing_image_ids) == len(all_image_ids)
    )
    valid_image = schema.clamp_bool_str(valid_image_set)

    evidence_standard_met = schema.clamp_bool_str(evidence_standard_met_bool)

    # --- manual_review_required policy (see module docstring) -------------
    needs_manual_review = (
        verdict.model_confidence == "low"
        or claim_status == "contradicted"
        or ("possible_manipulation" in risk_flags)
        or ("non_original_image" in risk_flags)
        or ("text_instruction_present" in risk_flags)
        or (bool(history_risk.risk_flags) and claim_status != "not_enough_information")
    )
    if needs_manual_review and "manual_review_required" not in risk_flags:
        risk_flags.append("manual_review_required")

    risk_flags_str = schema.clean_risk_flags(risk_flags)

    # --- supporting image ids: only keep ids that were actually submitted -
    valid_ids = set(all_image_ids)
    supporting = [i for i in verdict.supporting_image_ids if i in valid_ids]
    supporting_str = ";".join(supporting) if supporting else "none"
    if claim_status != "supported" and not supporting:
        supporting_str = "none"

    # --- justification text: append history note if it materially informed
    # the manual-review decision, so the CSV is self-explanatory -----------
    justification = verdict.claim_status_justification.strip()
    if history_risk.note:
        justification = f"{justification} User history note: {history_risk.note}.".strip()

    evidence_reason = verdict.evidence_standard_met_reason.strip()
    if missing_image_ids:
        evidence_reason = (
            f"{evidence_reason} Note: referenced image(s) {', '.join(missing_image_ids)} "
            f"could not be loaded.".strip()
        )

    return FinalRow(
        user_id=user_id,
        image_paths=image_paths_field,
        user_claim=user_claim,
        claim_object=claim_object,
        evidence_standard_met=evidence_standard_met,
        evidence_standard_met_reason=evidence_reason,
        risk_flags=risk_flags_str,
        issue_type=issue_type,
        object_part=object_part,
        claim_status=claim_status,
        claim_status_justification=justification,
        supporting_image_ids=supporting_str,
        valid_image=valid_image,
        severity=severity,
    )


def build_fallback_row(
    *,
    user_id: str,
    image_paths_field: str,
    user_claim: str,
    claim_object: str,
    reason: str,
) -> FinalRow:
    """
    Used when the model call fails outright after retries (network outage,
    persistent 5xx, etc.) so the pipeline still emits one schema-valid row
    per input row rather than crashing the whole batch run.
    """
    return FinalRow(
        user_id=user_id,
        image_paths=image_paths_field,
        user_claim=user_claim,
        claim_object=(claim_object or "").strip().lower(),
        evidence_standard_met="false",
        evidence_standard_met_reason=f"Automated review failed: {reason}",
        risk_flags="manual_review_required",
        issue_type="unknown",
        object_part="unknown",
        claim_status="not_enough_information",
        claim_status_justification=(
            "The automated reviewer could not complete evaluation for this "
            "claim due to a processing error; routed to manual review."
        ),
        supporting_image_ids="none",
        valid_image="false",
        severity="unknown",
    )
