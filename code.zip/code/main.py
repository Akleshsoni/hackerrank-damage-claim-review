#!/usr/bin/env python3
"""
main.py
========
CLI entry point for the Multi-Modal Evidence Review system.

Usage:
    python main.py --input dataset/claims.csv --output dataset/output.csv
    python main.py --input dataset/sample_claims.csv --output evaluation/sample_predictions.csv

Reads ANTHROPIC_API_KEY from the environment (never hardcoded). See
code/README.md for setup instructions.
"""

from __future__ import annotations

import argparse
import os
import sys

from evidence_review.pipeline import ClaimReviewPipeline, read_claims_csv, write_output_csv


def main() -> int:
    parser = argparse.ArgumentParser(description="Multi-Modal Evidence Review")
    parser.add_argument("--input", required=True, help="Path to claims CSV (e.g. dataset/claims.csv)")
    parser.add_argument("--output", required=True, help="Path to write output.csv")
    parser.add_argument(
        "--dataset-root", default=None,
        help="Root directory image_paths are relative to (defaults to the input file's directory)",
    )
    parser.add_argument(
        "--evidence-requirements", default=None,
        help="Path to evidence_requirements.csv (defaults to <dataset-root>/evidence_requirements.csv)",
    )
    parser.add_argument(
        "--user-history", default=None,
        help="Path to user_history.csv (defaults to <dataset-root>/user_history.csv)",
    )
    parser.add_argument("--model", default=os.environ.get("EVIDENCE_REVIEW_MODEL", "claude-sonnet-4-6"))
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument(
        "--cache-dir", default=os.path.join(os.path.dirname(__file__), ".cache"),
        help="Disk cache directory; set to '' to disable caching",
    )
    args = parser.parse_args()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print(
            "ERROR: ANTHROPIC_API_KEY is not set. Export it before running, e.g.\n"
            "  export ANTHROPIC_API_KEY=sk-ant-...",
            file=sys.stderr,
        )
        return 1

    dataset_root = args.dataset_root or os.path.dirname(os.path.abspath(args.input))
    evidence_path = args.evidence_requirements or os.path.join(dataset_root, "evidence_requirements.csv")
    history_path = args.user_history or os.path.join(dataset_root, "user_history.csv")
    cache_dir = args.cache_dir or None

    print(f"[INFO] input={args.input}", file=sys.stderr)
    print(f"[INFO] dataset_root={dataset_root}", file=sys.stderr)
    print(f"[INFO] evidence_requirements={evidence_path} (exists={os.path.exists(evidence_path)})", file=sys.stderr)
    print(f"[INFO] user_history={history_path} (exists={os.path.exists(history_path)})", file=sys.stderr)
    print(f"[INFO] model={args.model}, max_workers={args.max_workers}, cache_dir={cache_dir}", file=sys.stderr)

    rows = read_claims_csv(args.input)
    print(f"[INFO] loaded {len(rows)} input rows", file=sys.stderr)

    pipeline = ClaimReviewPipeline(
        dataset_root=dataset_root,
        evidence_requirements_path=evidence_path,
        user_history_path=history_path,
        model=args.model,
        cache_dir=cache_dir,
        max_workers=args.max_workers,
    )

    results = pipeline.run(rows)
    write_output_csv(results, args.output)

    usage = pipeline.usage_summary()
    print(f"[INFO] wrote {len(results)} rows to {args.output}", file=sys.stderr)
    print(f"[INFO] usage summary: {usage}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
