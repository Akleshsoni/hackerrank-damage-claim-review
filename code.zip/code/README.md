# Multi-Modal Evidence Review

A claim-review system that decides whether submitted images **support**,
**contradict**, or provide **not enough information** about a customer's
damage claim (car / laptop / package), using a single multimodal LLM call
per claim plus a thin, fully deterministic decision layer.

## How it works (one paragraph)

For each claim: read the chat transcript and submitted images; look up the
minimum evidence checklist for that object type from
`evidence_requirements.csv`; look up the user's risk history from
`user_history.csv`; send the transcript + checklist + all images in one
multimodal request to Claude, forcing a structured `record_claim_review`
tool call (not free-text JSON parsing); then deterministically fuse the
model's verdict with history-derived risk flags and run it through a set of
schema-validity and internal-consistency guards before writing the row.
**The images are the only thing that ever decides `claim_status`** — history
and conversation text only ever add risk flags or feed the prompt context,
never override a visual verdict (see `code/evidence_review/decision.py`
module docstring for the exact, auditable rules).

## Project layout

```
code/
  main.py                         CLI entry point
  requirements.txt
  evidence_review/
    schema.py                     allowed-value vocab + clamping helpers
    conversation.py               injection-attempt detection, transcript formatting
    user_history.py               user_history.csv loader + risk scoring
    evidence_requirements.py      evidence_requirements.csv loader + matching
    vision_agent.py                the single multimodal model call (tool-use schema + system prompt)
    decision.py                   deterministic fusion -> final output row
    pipeline.py                   orchestration: CSV in -> threaded calls -> cache -> CSV out
    batch_runner.py                optional Anthropic Message Batches API path (large-scale alternative)
    tests/test_offline.py         logic tests that need ZERO API calls
evaluation/
  evaluate.py                     scores predictions against dataset/sample_claims.csv
  evaluation_report.md            operational analysis (cost/latency/rate-limit reasoning)
dataset/                          (not included in code.zip; see Setup)
```

## Setup

```bash
cd code
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...
```

Place the real dataset (as shipped in the hackathon repo) at the repo root:

```
dataset/
  claims.csv
  sample_claims.csv
  user_history.csv
  evidence_requirements.csv
  images/sample/...
  images/test/...
```

## Running

**1. Evaluate on the labeled sample first (required workflow):**

```bash
python evaluation/evaluate.py
```

This runs the real pipeline against every row in `dataset/sample_claims.csv`,
writes `evaluation/sample_predictions.csv`, prints a per-field accuracy
table, and writes `evaluation/sample_eval_diffs.csv` listing every row with
at least one mismatched field (for manual inspection / prompt iteration).

**2. Run the offline (no-API) logic tests:**

```bash
python -m unittest evidence_review.tests.test_offline -v
```

These do not call the model at all — they validate schema clamping,
injection detection, decision fusion, and CSV shape. Run them any time you
change `decision.py` or `schema.py` to catch regressions for free.

**3. Produce the real submission output:**

```bash
python main.py --input ../dataset/claims.csv --output ../dataset/output.csv
```

`output.csv` will have exactly one row per input row, in the exact column
order required by `problem_statement.md`.

## Design notes worth knowing before the AI-judge interview

- **One model call per claim, not per image.** Damage assessment is
  comparative — a wide context shot plus a close-up are often only jointly
  conclusive. See `vision_agent.py` module docstring point 1 for the
  detailed reasoning and a worked example from the dataset.
- **Structured output via forced tool-use**, not "respond in JSON." This
  avoids the entire class of "model added a sentence before the JSON" /
  markdown-fence parsing failures, and lets every enum field be constrained
  at the schema level (`tool_choice={"type": "tool", "name": "record_claim_review"}`).
- **Prompt-injection defense is layered**, not single-point: a deterministic
  regex backstop (`conversation.detect_injection_attempts`) catches known
  phrasings (including a transliterated Hindi/Hinglish variant found in the
  data), AND the system prompt instructs the model to treat all transcript
  and in-image text as untrusted content in any language and self-report
  `text_instruction_present` when it notices an attempt the regex missed.
  `decision.py` additionally forces `manual_review_required` whenever
  `text_instruction_present` fires, regardless of what claim_status the
  model otherwise reached.
- **History never overrides vision.** `user_history.py`'s `assess()` method
  only ever returns risk *flags* and a *note* string; it has no way to set
  `claim_status` or `evidence_standard_met`, structurally enforcing the
  spec's "user history can add risk context, but should not override clear
  visual evidence" requirement rather than just instructing the model to
  behave that way and hoping.
- **Internal consistency guards** in `decision.py` enforce relationships
  that hold as strict equivalences in the labeled sample data (verified
  empirically against every row of `sample_claims.csv`), e.g.
  `evidence_standard_met=false  <=>  claim_status=not_enough_information`,
  and `not_enough_information => issue_type/severity = unknown` (while
  `object_part` is deliberately left un-clamped in that case, matching the
  labeled pattern where the model can still name *which* part it lacked
  enough evidence on).
- **No hardcoded test-row logic anywhere.** Nothing in `code/` branches on a
  `case_XXX` id, a `user_id`, or reads any `expected_*`/labeled column from
  `sample_claims.csv`. The only file that ever reads expected-output columns
  is `evaluation/evaluate.py`, and it only does so to score predictions
  *after* they're produced by the unmodified production pipeline.
- **Why threads + disk cache, not the Batch API, for this run.** See
  `pipeline.py` module docstring and `evaluation/evaluation_report.md` for
  the cost/latency tradeoff; `batch_runner.py` documents the Batch API path
  for when claim volume is large enough that the 50% discount and slower
  turnaround become the better trade.

## Known limitations (stated rather than hidden)

- The deterministic injection-pattern list is enumerable and not
  exhaustive — it is a backstop, not the primary defense (the system prompt
  is). See `conversation.py` docstring.
- `evidence_requirements.py`'s matching between a free-text issue hint and
  `applies_to` rows is a soft keyword-overlap heuristic, not a learned
  classifier; it falls back gracefully to an `all`-scoped or default
  requirement text when no good match is found, but it can occasionally
  hand the model a less specific checklist than a human curator would pick.
- Severity estimation is the least constrained field in the schema (no
  explicit rubric is given in `problem_statement.md` beyond the enum); the
  system prompt asks the model to judge severity from visible damage only,
  but two reasonable reviewers could disagree at the low/medium boundary.
